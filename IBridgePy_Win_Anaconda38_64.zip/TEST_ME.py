import datetime as dt
from data_provider_factory.data_loading_plan import HistIngestionPlan, Plan
from IBridgePy.IbridgepyTools import symbol, superSymbol
from configuration import test_me

# fileName = 'example_show_positions.py'
# fileName = 'example_show_real_time_prices.py'
# fileName = 'example_get_historical_data.py'
# fileName = 'example_place_order.py'
fileName = 'demo_close_price_reversion.py'

# logLevel = 'DEBUG'

accountCode = 'DU1868499'  # IB accountCode is needed to retrieve historical data from IB server.
dataProviderName = 'IB'  # RANDOM, IB, LOCAL_FILE
runMode = 'RUN_LIKE_QUANTOPIAN'

# histIngestionPlan is a reserved word in IBridgePy to store the historical data ingestion plan
# It is an instance of HistIngestionPlan.
# The add function is used to add more Ingestion Plans if needed
# http://www.ibridgepy.com/2019/05/20/backtest-strategies-ibridgepy/
# histIngestionPlan = HistIngestionPlan()
# histIngestionPlan.add(Plan(security=symbol('SPY'), barSize='1 min', goBack='10 D'))
# histIngestionPlan.add(Plan(security=symbol('SPY'), barSize='1 day', goBack='30 D'))
# histIngestionPlan.add(Plan(security=symbol('AAPL'), barSize='1 day', goBack='30 D'))
# histIngestionPlan.add(Plan(security=symbol('GOOG'), barSize='1 day', goBack='30 D'))

# In AUTO mode, backtesting time series will be created automatically based on endTime, startTime and freq
timeGeneratorType = 'AUTO'
# As a demo, the backtesting starts from 4 days ago, and ends at the current datetime.
endTime = dt.datetime.now().replace(second=0)  # default timezone = 'US/Eastern'
startTime = endTime - dt.timedelta(days=4)  # default timezone = 'US/Eastern'
freq = '1T'  # 1S = 1 second; 1T = 1 minute; 1H = 1 hour


test_me(fileName, globals())
