# coding=utf-8
from IBridgePy.constants import BrokerName, DataProviderName

PROJECT = {
    'brokerName': BrokerName.LOCAL_BROKER,
}


BROKER_CLIENT = {
    'IB_CLIENT': {
        'accountCode': '',
        'host': '',
        'port': 7496,
        'clientId': 9,
    }
}
