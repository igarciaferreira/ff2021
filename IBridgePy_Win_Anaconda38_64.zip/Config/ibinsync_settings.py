# coding=utf-8
from IBridgePy.constants import BrokerName, DataProviderName

PROJECT = {
    'dataProviderName': DataProviderName.IB,
    'brokerName': BrokerName.IBinsync,
}


BROKER_CLIENT = {
    'IB_CLIENT': {
        'accountCode': '',
        'host': '',
        'port': 7496,
        'clientId': 9,
    }
}
