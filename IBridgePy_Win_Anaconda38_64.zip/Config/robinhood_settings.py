# coding=utf-8
from IBridgePy.constants import BrokerName, DataProviderName

PROJECT = {
    'dataProviderName': DataProviderName.ROBINHOOD,
    'brokerName': BrokerName.ROBINHOOD
}


MARKET_MANAGER = {
    'baseFreqOfProcessMessage': 0,  # dont run Trader::processMessage()
}
