# coding=utf-8
from Config.config_defs import UserConfig
from configuration import _build_config


def build_active_IBridgePy_plus(accountCode):
    userConfig = UserConfig().get_config('IBinsync')
    userConfig.projectConfig.accountCode = accountCode
    userConfig.projectConfig.logLevel = 'INFO'
    userConfig = _build_config(userConfig)
    userConfig.trader.connect()
    userConfig.trader.display_all()
    return userConfig.trader


def build_active_TD_trader(accountCode):
    userConfig = UserConfig.get_config('TD')
    userConfig.projectConfig.accountCode = accountCode
    userConfig.projectConfig.logLevel = 'INFO'
    userConfig = _build_config(userConfig)
    userConfig.trader.connect()
    return userConfig.trader
