# -*- coding: utf-8 -*-
"""
All rights reserved.
@author: IBridgePy@gmail.com
"""
from IBridgePy.constants import BrokerName, LogLevel
from models.Data import DataFromServer
from models.SingleTrader import SingleTrader


# put here to avoid cyclic import
def _invoke_log(userConfig, caller, message):
    if userConfig.projectConfig.logLevel in [LogLevel.DEBUG, LogLevel.NOTSET]:
        print(__name__ + '::%s:%s' % (caller, message))


class BrokerClientFactory(object):
    def __init__(self):
        self._brokerClientFactoryDict = {}

    def __str__(self):
        if not self._brokerClientFactoryDict:
            return '{Empty dict}'
        ans = '{'
        for key in self._brokerClientFactoryDict:
            ans += '%s:%s ' % (key, self._brokerClientFactoryDict[key])
        ans = ans[:-1] + '}'
        return ans

    def get_brokerClient_by_name(self, brokerName, userConfig):
        _invoke_log(userConfig, 'get_dataClient_by_name', brokerName)
        if brokerName in self._brokerClientFactoryDict:
            t = self._brokerClientFactoryDict[brokerName]
            _invoke_log(userConfig, 'get_dataClient_by_name', 'found brokerClient=%s in brokerClientFactory' % (t,))
            return t
        else:
            return self._create_brokerClient_by_name(brokerName, userConfig)

    def _create_brokerClient_by_name(self, brokerName, userConfig):
        _invoke_log(userConfig, '_create_brokerClient_by_name', brokerName)
        if brokerName == BrokerName.LOCAL_BROKER:
            from .BrokerClient_Local import ClientLocalBroker
            t = ClientLocalBroker()
            accountCode = 'testAccountCode'
            t.setup_client_local_broker(userConfig.log,
                                        accountCode,
                                        userConfig.projectConfig.rootFolderPath,
                                        SingleTrader(userConfig.log),
                                        DataFromServer(),
                                        userConfig.timeGenerator,
                                        None)
        elif brokerName in [BrokerName.IB, BrokerName.IBinsync]:
            from .BrokerClient_IB import ClientIB
            """
            !!! BrokerClient class does not have any constructor because it extends IBClient from IBCpp.
            !!! To create an instance, just create and then call setup_client_xxx
            """
            t = ClientIB()
            accountCode = userConfig.brokerClientConfig.IB_CLIENT['accountCode']
            if not accountCode:
                raise RuntimeError("IB_CLIENT['accountCode'] is empty. Please check setting.py --> BROKER_CLIENT --> IB_CLIENT --> accountCode")
            t.setup_client_IB(userConfig.log,
                              accountCode,
                              userConfig.projectConfig.rootFolderPath,
                              SingleTrader(userConfig.log),
                              DataFromServer(),
                              userConfig.timeGenerator,
                              userConfig.brokerClientConfig.IB_CLIENT['host'],
                              userConfig.brokerClientConfig.IB_CLIENT['port'],
                              userConfig.brokerClientConfig.IB_CLIENT['clientId'])
        elif brokerName == BrokerName.ROBINHOOD:
            from .BrokerClient_Robinhood import BrokerClientRobinhood
            from .Robinhood.robinhoodClient import RobinhoodClient

            robinhoodClient = RobinhoodClient()
            t = BrokerClientRobinhood()
            accountCode = userConfig.brokerClientConfig.ROBINHOOD_CLIENT['accountCode']
            if not accountCode:
                raise RuntimeError(
                    "ROBINHOOD_CLIENT['accountCode'] is empty. Please check setting.py --> BROKER_CLIENT --> ROBINHOOD_CLIENT --> accountCode")
            t.setup_brokerClient_Robinhood(userConfig.log,
                                           userConfig.projectConfig.rootFolderPath,
                                           SingleTrader(userConfig.log),
                                           DataFromServer(),
                                           userConfig.timeGenerator,
                                           robinhoodClient,
                                           accountCode,
                                           userConfig.brokerClientConfig.ROBINHOOD_CLIENT['username'],
                                           userConfig.brokerClientConfig.ROBINHOOD_CLIENT['password'])

        elif brokerName == BrokerName.TD:
            from broker_client_factory.TdAmeritrade import TDClient
            from .BrokerClient_TdAmeritrade import BrokerClientTdAmeritrade
            tdClient = TDClient(userConfig.brokerClientConfig.TD_CLIENT['refreshToken'],
                                userConfig.brokerClientConfig.TD_CLIENT['apiKey'],
                                userConfig.brokerClientConfig.TD_CLIENT['refreshTokenCreatedOn'],
                                [userConfig.projectConfig.accountCode],
                                userConfig.log)
            t = BrokerClientTdAmeritrade()
            accountCode = userConfig.brokerClientConfig.TD_CLIENT['accountCode']
            if not accountCode:
                raise RuntimeError(
                    "TD_CLIENT['accountCode'] is empty. Please check setting.py --> BROKER_CLIENT --> TD_CLIENT --> accountCode")
            t.setup_brokerClient_TDAmeritrade(userConfig.log,
                                              userConfig.projectConfig.rootFolderPath,
                                              SingleTrader(userConfig.log),
                                              DataFromServer(),
                                              userConfig.timeGenerator,
                                              tdClient,
                                              accountCode)
        else:
            raise RuntimeError(__name__ + '::get_brokerClient: cannot handle brokerName = %s' % (brokerName,))
        assert (t is not None)
        t.connectWrapper()
        _invoke_log(userConfig, 'get_brokerClient', 'created brokerClient=%s id=%s dataProvider=None is correct at the moment, setup_services will invoke later.' % (t.name, id(t)))
        self._brokerClientFactoryDict[t.name] = t
        return t

    def get_brokerClient_by_userConfig(self, userConfig):
        _invoke_log(userConfig, 'get_brokerClient_by_userConfig', 'start')
        brokerName = userConfig.projectConfig.brokerName

        if brokerName in self._brokerClientFactoryDict:
            t = self._brokerClientFactoryDict[brokerName]
            _invoke_log(userConfig, 'get_brokerClient_by_userConfig',
                        'found brokerClient=%s in brokerClientFactory' % (t,))
            return t

        if brokerName == BrokerName.LOCAL_BROKER:
            from .BrokerClient_Local import ClientLocalBroker
            t = ClientLocalBroker()
            t.setup_client_local_broker(userConfig.log,
                                        userConfig.projectConfig.accountCode,
                                        userConfig.projectConfig.rootFolderPath,
                                        userConfig.singleTrader,
                                        userConfig.dataFromServer,
                                        userConfig.timeGenerator,
                                        userConfig.dataProvider)
        elif brokerName == BrokerName.IB:
            from .BrokerClient_IB import ClientIB
            """
            !!! BrokerClient class does not have any constructor because it extends IBClient from IBCpp.
            !!! To create an instance, just create and then call setup_client_xxx
            """
            t = ClientIB()
            t.setup_client_IB(userConfig.log,
                              userConfig.projectConfig.accountCode,
                              userConfig.projectConfig.rootFolderPath,
                              userConfig.singleTrader,
                              userConfig.dataFromServer,
                              userConfig.timeGenerator,
                              userConfig.brokerClientConfig.IB_CLIENT['host'],
                              userConfig.brokerClientConfig.IB_CLIENT['port'],
                              userConfig.brokerClientConfig.IB_CLIENT['clientId'])
        elif brokerName == BrokerName.IBinsync:
            from .BrokerClient_IBinsync import IBinsync
            """
            !!! BrokerClient class does not have any constructor because it extends IBClient from IBCpp.
            !!! To create an instance, just create and then call setup_client_xxx
            """
            t = IBinsync()
            t.setup_client_IBinsync(userConfig.log,
                                    userConfig.projectConfig.accountCode,
                                    userConfig.projectConfig.rootFolderPath,
                                    userConfig.singleTrader,
                                    userConfig.dataFromServer,
                                    userConfig.timeGenerator,
                                    userConfig.brokerClientConfig.IB_CLIENT['host'],
                                    userConfig.brokerClientConfig.IB_CLIENT['port'],
                                    userConfig.brokerClientConfig.IB_CLIENT['clientId'])
        elif brokerName == BrokerName.ROBINHOOD:
            from .BrokerClient_Robinhood import BrokerClientRobinhood
            from .Robinhood.robinhoodClient import RobinhoodClient

            robinhoodClient = RobinhoodClient()
            t = BrokerClientRobinhood()
            t.setup_brokerClient_Robinhood(userConfig.log,
                                           userConfig.projectConfig.rootFolderPath,
                                           userConfig.singleTrader,
                                           userConfig.dataFromServer,
                                           userConfig.timeGenerator,
                                           robinhoodClient,
                                           userConfig.projectConfig.accountCode,
                                           userConfig.brokerClientConfig.ROBINHOOD_CLIENT['username'],
                                           userConfig.brokerClientConfig.ROBINHOOD_CLIENT['password'])

        elif brokerName == BrokerName.TD:
            from broker_client_factory.TdAmeritrade import TDClient
            from .BrokerClient_TdAmeritrade import BrokerClientTdAmeritrade
            tdClient = TDClient(userConfig.brokerClientConfig.TD_CLIENT['refreshToken'],
                                userConfig.brokerClientConfig.TD_CLIENT['apiKey'],
                                userConfig.brokerClientConfig.TD_CLIENT['refreshTokenCreatedOn'],
                                [userConfig.projectConfig.accountCode],
                                userConfig.log)
            t = BrokerClientTdAmeritrade()
            t.setup_brokerClient_TDAmeritrade(userConfig.log,
                                              userConfig.projectConfig.rootFolderPath,
                                              userConfig.singleTrader,
                                              userConfig.dataFromServer,
                                              userConfig.timeGenerator,
                                              tdClient,
                                              userConfig.projectConfig.accountCode)
        else:
            raise RuntimeError(__name__ + '::get_brokerClient: cannot handle brokerName = %s' % (brokerName,))
        assert (t is not None)
        t.connectWrapper()
        _invoke_log(userConfig, 'get_brokerClient', 'created brokerClient=%s id=%s dataProvider=None is correct at the moment, setup_services will invoke later.' % (t.name, id(t)))
        self._brokerClientFactoryDict[t.name] = t
        return t
